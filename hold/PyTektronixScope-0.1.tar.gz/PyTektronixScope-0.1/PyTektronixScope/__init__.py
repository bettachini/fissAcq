from PyTektronixScope import *
